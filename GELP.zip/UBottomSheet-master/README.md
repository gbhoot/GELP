# UBottomSheet
Bottom sheet that mimics the behaviours and UI of iPhone Maps app.

<img src="UBottomSheet/anim.gif" width="300">
