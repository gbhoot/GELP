//
//  HomeCategoryCollectionViewCell.swift
//  UBottomSheet
//
//  Created by Kim Do on 11/8/18.
//  Copyright © 2018 otw. All rights reserved.
//

import UIKit

class HomeCategoryCollectionViewCell: UICollectionViewCell {
   
   @IBOutlet weak var label: UILabel!
   
}
