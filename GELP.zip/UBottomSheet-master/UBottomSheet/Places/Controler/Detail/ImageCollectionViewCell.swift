//
//  ImageCollectionViewCell.swift
//  UBottomSheet
//
//  Created by Kim Do on 11/9/18.
//  Copyright © 2018 otw. All rights reserved.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
   @IBOutlet weak var image: UIImageView!
   
}
