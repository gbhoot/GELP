//
//  FavoritePlace.swift
//  UBottomSheet
//
//  Created by Gurpal Bhoot on 11/9/18.
//  Copyright © 2018 otw. All rights reserved.
//

import UIKit

class FavoritePlace {
    
    var placeName: String?
    
    init(placeName: String) {
        self.placeName = placeName
    }
}
